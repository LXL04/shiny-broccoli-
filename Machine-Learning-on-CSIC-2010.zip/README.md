# Machine-Learning-on-CSIC-2010
机器学习实战之CSIC2010网络攻击数据
