import os
from ids_log_mysql import ids_log_mysql

conn = ids_log_mysql()
text = conn.show_ids_config()

print(text[0])
server_ip = text[0][1]
server_port = text[0][2]
m_port = text[0][4]
cmd = 'mitmdump -p ' + m_port + ' --mode reverse:http://' + server_ip + ':' + server_port + ' -s demo1.py'
os.system("cmd /k start " + cmd)  # /k保留窗口
