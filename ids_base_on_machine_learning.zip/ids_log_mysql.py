import pymysql


class ids_log_mysql:
    def __init__(self):
        self.conn = pymysql.connect(
            host='127.0.0.1',
            user='root',
            password='root',
            db='ids_log',
            charset='utf8'
        )

    def host_info(self):
        return self.conn.host_info

    def insert_to_db(self, ip, req_info, evil_proda):
        sql = "insert into ids_logs(time_,ip,req_info,evil_proda) value (now(),%s,%s,%s)"
        cursor = self.conn.cursor()
        cursor.execute(sql, (ip, req_info, evil_proda))
        self.conn.commit()

    def show_ids_config(self):
        sql = "select * from ids_config "
        cursor = self.conn.cursor()
        cursor.execute(sql)
        return cursor.fetchall()
