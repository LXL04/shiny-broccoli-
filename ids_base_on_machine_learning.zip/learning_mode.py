import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import re
import numpy as np


class misuse_detection:
    def __init__(self, raw):
        self.raw = raw

    def raw_to_vector(self, data=str('')):
        feature = []
        data = self.raw
        for i in range(len(data)):
            # 采用 split("?", 1)是为了处理形如 http://127.0.0.1/?open=?123的URL
            s = data[i].split("?", 1)
            if len(s) != 1:

                url_len = len(data[i])  # URL长度

                method = data[i].split(" ")[0]  # 请求类型
                if method == "GET":
                    url_method = 1
                elif method == "POST":
                    url_method = 2
                else:
                    url_method = 3

                query = s[1]
                parameter_len = len(query)  # 参数部分长度
                parameters = query.split("&")
                parameter_num = len(parameters)  # 参数的个数

                parameter_max_len = 0  # 参数的最大长度
                parameter_number_num = 0  # 参数的数字个数
                parameter_str_num = 0
                parameter_spe_num = 0
                par_val_sum = 0

                for parameter in parameters:
                    try:
                        # 采用 split("=", 1)是为了处理形如 open=123=234&file=op的参数
                        [par_name, par_val] = parameter.split("=", 1)
                    except ValueError as err:
                        # 处理形如 ?open 这样的参数
                        print(err)
                        print(data[i])
                        break

                    par_val_sum += len(par_val)
                    if parameter_max_len < len(par_val):
                        parameter_max_len = len(par_val)
                    parameter_number_num += len(re.findall("\d", par_val))
                    parameter_str_num += len(re.findall(r"[a-zA-Z]", par_val))
                    parameter_spe_num += len(par_val) - len(re.findall("\d", par_val)) - len(
                        re.findall(r"[a-zA-Z]", par_val))  # 特殊字符所占比例

                try:
                    parameter_number_rt = parameter_number_num / par_val_sum  # 参数值中数字所占比例
                    parameter_str_rt = parameter_str_num / par_val_sum  # 参数值中字母所占比例
                    parameter_spe_rt = parameter_spe_num / par_val_sum  # 特殊字符所占比例
                    feature.append([url_len, url_method, parameter_len, parameter_num,
                                    parameter_max_len, parameter_number_num, parameter_str_num,
                                    parameter_spe_num, parameter_number_rt, parameter_str_rt,
                                    parameter_spe_rt])
                    # URL长度
                    # 请求类型
                    # 参数部分的长度
                    # 参数的个数
                    # 参数的最大长度
                    # 参数中数字个数
                    # 参数中字符个数
                    # 参数中特殊字符的个数
                    # 参数值中数字所占比例
                    # 参数值中字母所占比例
                    # 参数值中特殊字符所占比例

                except ZeroDivisionError as err:
                    print(err)
                    print(data[i])
                    continue
        return feature

    def random_forest_mode(self):
        standardScalar = joblib.load('D:\pythonproject\ids_base_on_machine_learning\scalar01_3.pkl')
        vector = self.raw_to_vector()
        if vector:
            std_vct = standardScalar.transform(vector)
            loaded_model = joblib.load('D:\pythonproject\ids_base_on_machine_learning\\rf_clf_3.pkl')
            y_pred = loaded_model.predict_proba(std_vct)
            print(y_pred[0][1])
            if y_pred[0][1] > 0.86:
                return y_pred[0][1]
            else:
                return 'null'
        else:
            return 'null'

# predict = misuse_detection(['GET http://127.0.0.1:8888/favicon.ico/n?id=2132'])
# print("流量为恶意的概率为:" + str(predict.random_forest_mode()))
