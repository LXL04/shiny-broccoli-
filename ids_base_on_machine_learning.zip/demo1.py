import os
from mitmproxy import ctx, http
import json
from ids_log_mysql import ids_log_mysql
import pymysql
from learning_mode import misuse_detection
from mitmproxy import proxy, options
from mitmproxy.tools.dump import DumpMaster
from mitmproxy.addons import core
import warnings
import urllib.parse as parse

warnings.filterwarnings("ignore")


def is_chinese(ch):
    if u'\u4e00' <= ch <= u'\u9fff':
        return True
    else:
        return False


def str_is_chinese(str_):
    for i, c in enumerate(str_):
        if is_chinese(c) is True:
            print(c)
            str_ = str_.replace(c, 'c')
    return str_


class Modify:
    def __init__(self):
        self.conn = ids_log_mysql()  # 数据库类
        self.predict = misuse_detection([])  # ids_model类

    def request(self, flow):
        headers = []
        evil_proda = 'null'
        url = None
        if flow.request.method == 'POST':
            if dict(flow.request.headers)['Content-Type'] == 'application/x-www-form-urlencoded':  # 只对urlencoded进行检测

                url_p = parse.unquote(flow.request.text)
                url_p = str_is_chinese(url_p)
                url_p = parse.quote(url_p, safe=";/?:@&=+$,")
                url = flow.request.method + ' ' + flow.request.pretty_url + '?' + url_p
                print(url)



        if flow.request.method == 'GET':
            url_p = parse.unquote(flow.request.pretty_url)
            url_p = str_is_chinese(url_p)
            url_p = parse.quote(url_p,safe=";/?:@&=+$,")
            url = flow.request.method + ' ' + url_p
            print(url)
        print('-' * 100)
        if url is not None:
            self.predict.raw = [url]
            evil_proda = self.predict.random_forest_mode()
        if url is None:
            print('from-data')
        if evil_proda != 'null':
            flow.request.path = '/error/403.html'
            print('这可能是一条恶意请求，已存入数据库,evil_proda:' + str(evil_proda))
            data = {
                'req_line': url,
                'req_headers': dict(flow.request.headers),
                'req_body': flow.request.text
            }
            data = json.dumps(data)
            self.conn.insert_to_db(flow.request.host, data, evil_proda)
        print('-' * 101)


addons = [
    Modify()
]
