// pages/cat_log/cat_log.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      logs: [{'time_': '2022-04-22 17:07:05', 'ip': '127.0.0.1', 'req_info': '{"req_line": "GET http://127.0.0.1:8888/Less-1/?id=1%20and%201=1", "req_headers": {"Host": "127.0.0.1:8888", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:99.0) Gecko/20100101 Firefox/99.0", "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8", "Accept-Language": "zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2", "Accept-Encoding": "gzip, deflate, br", "Connection": "keep-alive", "Cookie": "XXL_JOB_LOGIN_IDENTITY=7b226964223a312c22757365726e616d65223a2261646d696e222c2270617373776f7264223a223864646366663361383066343138396361316339643464393032633363393039222c22726f6c65223a312c227065726d697373696f6e223a6e756c6c7d; username-127-0-0-1-8888=\\"2|1:0|10:1650360137|23:username-127-0-0-1-8888|44:MWE4OTEyODA2NDllNDYxOGEyNTY1NDRhMTEzMjI4Yzc=|70ab8ad975118db9bdb08bba4888dc5a4e4de6046a88201c57d7920a0341cd5b\\"; _xsrf=2|15096f9a|36f209c762b0b9f8a41d30fd92fded2d|1650360137", "Upgrade-Insecure-Requests": "1", "Sec-Fetch-Dest": "document", "Sec-Fetch-Mode": "navigate", "Sec-Fetch-Site": "none", "Sec-Fetch-User": "?1"}, "req_body": ""}', 'evil_proda': 0.948}],
      show: false,
      th:["time","ip","evil_proda","req_info"],
      req_info: {},


  },
    hideCover(){
      this.setData({
        show: false
      })
    },
    showCover(){
      this.setData({
        show:true
      })
    },

    onClickHide() {
      this.setData({ show: false });
    },

    noop() {},
  /**
   * 生命周期函数--监听页面加载
   */
  onSearch(e){
    var that = this
    console.log(e.detail)
    wx.request({
      url: 'http://127.0.0.1:5000/search?key='+e.detail,
      success(res){
        console.log(res.data.length)
        if (res.data.length != 0)
        {
          that.setData({
            logs: res.data
          })
        }
        else{
          that.setData({
            logs: []
          })
        }
        console.log(that.data.logs.length)
      },
      fail(res){
        console.log("请求数据库失败")
        wx.showToast({
          title: '请求数据库失败',
          icon: 'error',
          duration: 2000
        })
      }
    })

  },
  click(e){
    console.log(e.currentTarget.dataset.detail)
    console.log(typeof(e.currentTarget.dataset.detail))
    this.setData({ show: true });
    this.setData({req_info: JSON.parse(e.currentTarget.dataset.detail)})

   
      /*for (key in this.data.req_info.req_headers){
        console.log(key);
        //add your statement to get key value
    }*/
  },
  onLoad: function (options) {
    var that = this
    wx.request({
      url: 'http://127.0.0.1:5000/show_logs',
      success(res){
        console.log(res.data)
        that.setData({
          logs: res.data
        })
        console.log(that.data.logs[7])
      },
      fail(res){
        console.log("请求数据库失败")
        wx.showToast({
          title: '请求数据库失败',
          icon: 'error',
          duration: 2000
        })
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})