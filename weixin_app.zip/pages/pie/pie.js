import * as echarts from '../../ec-canvas/echarts';


Page({

  data: {
    lazyec: {
         lazyload: true
    },
    optiondata:[],
    th:['year','month','day','line'],
    type: 0,
    nowclientX: "",
    year:[],
    month:[],
    day:[],
    hour:[]

  },

  onLoad: function(options){
    //发起请求
    var that = this
    wx.request({
      url: 'http://127.0.0.1:5000/statistics?key',
      success(res){
        
        that.setData({
          optiondata: res.data
        })
        for(var i in res.data)
          that.data.year.push( res.data[i].name)
        console.log(that.data.year)
        console.log(that.data.optiondata)
      }
    })
      setTimeout(()=>this.init(),1000)
    //获取组件
    this.lazyComponent = this.selectComponent('#mychart-dom-pie')

  },
  unique(arr){
    return Array.from(new	Set(arr))
  },
  init (){//手动初始化
      var that = this
      this.lazyComponent.init(
        (canvas,width,height,dpr)=>{
           let chart = echarts.init(canvas,null,{
             width:width,
             height:height,
             devicePixelRatio:dpr
           })
            ////////////////////////////////////////////////////////////////////
            var legend_select =""
            for(var i in that.data.year)
              legend_select+= ' "'+that.data.year[i]+'":true ,'
            legend_select='{'+legend_select.substring(0,legend_select.length-1)+'}'
            legend_select = JSON.parse(legend_select)
            /////////////////////////////////////////////////////////////////////////
           let option = getOption(this.data.optiondata,this.data.year,legend_select,'pie')

           chart.setOption(option)
           chart.on('legendselectchanged',function(params){
            if (that.data.type == 0)
            {
              that.data.year = []
              for(var i in params.selected)
                if(params.selected[i] == true)
                    that.data.year.push(i)
            }
            if (that.data.type == 1)
            {
              that.data.month=[]
              for(var i in params.selected)
                if(params.selected[i] == true)
                  that.data.month.push(i)
            }
            if (that.data.type == 2)
            {
              that.data.day=[]
              for(var i in params.selected)
                if(params.selected[i] == true)
                {
                    that.data.day.push(i)
                }
                    console.log(that.data.day)
            }

          })
          chart.on('legendselectall', function(params){
              console.log(params.selected)
          })

           this.chart = chart //将图表示例绑定到 this上， 方便访问

           return chart
        })
  },
  updatecharts(data,legend,legend_all,type='pie'){
    var that = this
    that.chart.setOption({},true)
    let option = getOption(data,legend,legend_all,type)
    that.chart.setOption(option)
  },

  request_api(){/* 发送数据请求并渲染表格 */
    var that = this

    console.log(that.data.type)
    if(that.data.type == 0)
    {

        wx.request({
        url: 'http://127.0.0.1:5000/statistics?key',
        success(res){

          console.log(that.data.year)
          for(var i in res.data)
            that.data.year.push( res.data[i].name)
            ////////////////////////////////////////////////////////////////////
            var legend_select =""
            for(var i in that.data.year)
              legend_select+= ' "'+that.data.year[i]+'":true ,'
            legend_select='{'+legend_select.substring(0,legend_select.length-1)+'}'
            legend_select = JSON.parse(legend_select)
            /////////////////////////////////////////////////////////////////////////
          that.updatecharts(res.data,that.data.year,legend_select,'pie')
        }
      })
      
    }

    if(that.data.type == 1)
    {
      console.log(that.data.year)
      that.data.month=[]
        wx.request({
          url: 'http://127.0.0.1:5000/statistics',
          method:'POST',
          data:{
            "key_list":that.data.year
          },
          success(res){
            console.log(res.data)
            for(var j in res.data)
              that.data.month.push( res.data[j].name)//初始化month记录
            ////////////////////////////////////////////////////////////////////
            var legend_select =""
            for(var i in that.data.month)
              legend_select+= ' "'+that.data.month[i]+'":true ,'
            legend_select='{'+legend_select.substring(0,legend_select.length-1)+'}'
            legend_select = JSON.parse(legend_select)
            /////////////////////////////////////////////////////////////////////////

            that.updatecharts(res.data,that.data.month,legend_select,'pie')
          }
        })


    }

    if(that.data.type == 2)
    {
      console.log(that.data.month)
      this.data.day=[]
        wx.request({
          url: 'http://127.0.0.1:5000/statistics',
          method:'POST',
          data:{
            "key_list":that.data.month
          },
          success(res){
            console.log(res.data)
            for(var i in res.data)//加载获取的month记录
              that.data.day.push( res.data[i].name)
            ////////////////////////////////////////////////////////////////////
            var legend_select =""
            for(var i in that.data.day)
              legend_select+= ' "'+that.data.day[i]+'":true ,'
            legend_select='{'+legend_select.substring(0,legend_select.length-1)+'}'
            legend_select = JSON.parse(legend_select)
            /////////////////////////////////////////////////////////////////////////
            that.updatecharts(res.data,that.data.day,legend_select,'pie')
            }
        })
    }
    if(that.data.type == 3)
    {
      console.log(that.data.day)
      that.data.hour = []
      wx.request({
        url: 'http://127.0.0.1:5000/statistics',
        method:'POST',
        data:{
          "key_list":that.data.day
        },
        success(res){
          console.log(res.data)
          for(var i in res.data)//加载获取的month记录
            that.data.hour.push( res.data[i].name)
          ////////////////////////////////////////////////////////////////////
          var legend_select =""
          for(var i in that.data.hour)
            legend_select+= ' "'+that.data.hour[i]+'":true ,'
          legend_select='{'+legend_select.substring(0,legend_select.length-1)+'}'
          legend_select = JSON.parse(legend_select)
          /////////////////////////////////////////////////////////////////////////
          that.updatecharts(res.data,that.data.day,legend_select,'line')
          }
      })
    }




  },
  /*change_chart(e){
    var that = this
    if(e.currentTarget.id)
    this.setData({
      type:e.currentTarget.id
    })
    this.request_api()
    //获取组件
  },*/
  touchstart(e) {
		this.setData({
			nowclientX: e.changedTouches[0].clientX
		})
	},
	touchend(e) {
    let nowclientX = this.data.nowclientX;
    let nowtype = this.data.type;
    let clientX = e.changedTouches[0].clientX;
		if ((clientX - nowclientX) < 0) {
      console.log("向右滑动")
      if(this.data.type < 3)
      {
        this.setData({
          type: nowtype+1
        })
        this.request_api()
      }
		} else if(clientX > nowclientX){
      console.log("向左滑动")
      if(this.data.type > 0)
      {
        this.setData({
          type: nowtype-1
        })
        this.request_api()
      }
		}
	}

});

function getOption (data0,legend,legend_all,type)
{
  if (type == 'line')
    return {
      title: {
      },
      legend: {
        data: legend,
        padding:[350,20,0,0],
        z: 100
      },
      grid: {
        containLabel: true,
        top:10
      },
      tooltip: {
        show: true,
        trigger: 'axis'
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: ['0', '1', '2', '3', '4', '5', '6',
              '7','8','9','10','11','12','13','14','15',
              '16','17','18','19','20','21','22','23','24'],
        // show: false
      },
      yAxis: {
        x: 'center',
        type: 'value',
        min: (value) => {
          return value.min
        },
        max: (value) => {
          return value.max+5
        },
      
        splitNumber : 5,
        splitLine: {
          lineStyle: {
            type: 'dashed'
          }
        },
        scale:true
        // show: false
      },
      series: data0
    }

  else
  {
      return {
      tooltip: {
        trigger: 'item'
      },
      legend: {
        orient: 'horizontal',
        x:'center',      //可设定图例在左、右、居中
        y:'top',     //可设定图例在上、下、居中
        itemHeight: 20,
        itemWidth: 40,
        textStyle: {
          fontSize: 15
        },
        data:legend,
        selected:legend_all,
        padding:[250,50,0,0],

        

      },
      series: [
        {
          name: 'ids_logs:',
          type: 'pie',
          radius: ['10%', '70%'],
          center: ['50%','30%'],
          avoidLabelOverlap: false,
          itemStyle: {
            borderRadius: 10,
            borderColor: '#fff',
            borderWidth: 2
          },
          label: {
            show: false,
            position: 'center'
          },
          emphasis: {
            label: {
              show: false,
              fontSize: '20',
              fontWeight: 'bold'
            }
          },
          labelLine: {
            show: false
          },
          data: data0
        }
      ]
    }
  }
};
