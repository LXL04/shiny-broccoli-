// pages/setconfig/setconfig.js
const ap1p = getApp();
Page({
    
    /**
     * 页面的初始数据
     */
    
    data: {
            
            active: 3,
            userInfo: null,
            m_ip: '',
            m_port: '',
            ids_port: '',
            ids_ip: ''
            
        
    },
   
    formSubmit(e) {
      console.log('form发生了submit事件，携带数据为：', e.detail.value)
      
        ap1p.globalData.m_ip=e.detail.value.m_ip
        ap1p.globalData.m_port=e.detail.value.m_port
        ap1p.globalData.ids_ip=e.detail.value.ids_ip
        ap1p.globalData.ids_port=e.detail.value.ids_port

        wx.request({
          url: 'http://127.0.0.1:5000/set_config', 
          method: "POST",
          data: {
            m_ip: e.detail.value.m_ip,
            m_port: e.detail.value.m_port,
            ids_port: e.detail.value.ids_port,
            ids_ip: e.detail.value.ids_ip,
          },
          
          success (res) {
            console.log(res.data)
            wx.showToast({
              title: '更新数据成功',
              icon: 'success',
              duration: 2000
            })
            setTimeout(function () {
              wx.navigateBack({
                delta: 0,
              })//要延时执行的代码
             }, 1000)
          }
        })
        
    },
  
    formReset(e) {
      console.log('form发生了reset事件，携带数据为：', e.detail.value)
      this.setData({
        m_ip: '',
        m_port:'',
        ids_ip:'',
        ids_port:'',
        model: ''
      })
    },
    onChange(event) {
        this.setData({
          radio: event.detail,
        });
      },
    Change_radio(event) {
      this.setData({
        radio: event.detail,
      });
    },
    onClick(event) {
      const { name } = event.currentTarget.dataset;
      this.setData({
        radio: name,
      });
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
      var that = this
      
      wx.request({
        url: 'http://127.0.0.1:5000/set_config', //仅为示例，并非真实的接口地址,
        header: {
          'content-type': 'application/json' // 默认值
        },
        success (res) {
          console.log(res.data)
            that.setData({
              m_ip: res.data.m_ip,
              m_port: res.data.m_port,
              ids_port: res.data.ids_port,
              ids_ip: res.data.ids_ip
          })
        },
        fail (res){
          that.setData({
            
            m_ip: ap1p.globalData.m_ip,
            m_port: ap1p.globalData.m_port,
            ids_port: ap1p.globalData.ids_port,
            ids_ip: ap1p.globalData.ids_ip
          })
          wx.showToast({
            title: '请求数据库失败',
            icon: 'error',
            duration: 2000
          })


        }
      })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})