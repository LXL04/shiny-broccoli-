// pages/login/login.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
        username: 'admin' ,
        passwd: ''

  },
  formSubmit(e)
  {
      console.log("提交了数据：",e.detail.value)
      wx.request({
        url: 'http://127.0.0.1:5000/check_user?user=admin&passwd='+e.detail.value.passwd,
        timeout: '5000',
        success (res){
          console.log(res.data)
          if(res.data=='True')
          {
            console.log("登录成功")
            wx.redirectTo({
              url: '../index/index',
            })
          }
          else{
            console.log("用户名或密码错误")
            wx.showToast({
              title: '用户名或密码错误',
              icon: 'error',
              duration: 2000
            })
          }
        },
        fail(res){
          wx.showToast({
            title: '服务器错误',
            icon: 'error',
            duration: 2000
          })
        }

      })
      
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})